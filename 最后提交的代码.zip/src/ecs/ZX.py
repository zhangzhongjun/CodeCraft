# coding=utf-8
from collections import  Counter
import time
import math

def allocate(mainLimit,theOtherLimit,mainRequestList,theOtherRequestList,requestNames,numOfLimit):
    numOfLimit = numOfLimit + 1
    dic = list(zip(requestNames,mainRequestList,theOtherRequestList))
    dic = sorted(dic,key= lambda x:x[-1],reverse=False)
    dic = sorted(dic,key= lambda x:x[1],reverse=True)
    mainRequestList = list(i[1] for i in dic )
    requestNames =  list(i[0] for i in dic )
    theOtherRequestList =  list(i[2] for i in dic )
    mainLimit = float(mainLimit)
    theOtherLimit = float(theOtherLimit)
    need_num = math.ceil(sum(mainRequestList)/mainLimit)
    need_num_ =  math.ceil(sum(theOtherRequestList)/float(theOtherLimit))
    need_num = max(need_num,need_num_)
    free_sapces = [mainLimit] *int(need_num )
    num_fitted, fit_blocks, delet,rate = FFD(free_sapces, theOtherLimit, mainRequestList, theOtherRequestList,requestNames,0,0)
    for inedx in range(len(fit_blocks)):
        if fit_blocks[-1] == []:
            fit_blocks.pop(-1)
    return fit_blocks,delet,rate

def FFD(freeSpace, theOtherLimit, limitRequests, theOtherRequestList, requestNames,numOfLimit,numOfTheOtherLimit):
    numOfLimit = numOfLimit + numOfTheOtherLimit
    while True:
        a,b,c,d = commonFit(freeSpace, theOtherLimit, limitRequests, fit_func, theOtherRequestList, requestNames)
        if a !=0:
            break
    return a,b,c,d

def fit_func(freeSpace, theOtherLimit, memoryRequest, fit_spaces, fit_spaces_limit, fit_blocks,fit_blocks_usefull, memory_reqquest_list_limit_, requestName):

    fitSpaces,fit_spaces_limit_,fit_blocks_,fit_blocks_usefull_= zip(*list(sorted(zip(fit_spaces,fit_spaces_limit,fit_blocks,fit_blocks_usefull))))
    fitSpaces = list(fitSpaces)
    fit_spaces_limit_ = list(fit_spaces_limit_)
    fit_blocks = list(fit_blocks_)
    fit_blocks_usefull = list(fit_blocks_usefull_)
    for i in range(len(freeSpace)):
        if (fitSpaces[i] + memoryRequest <= freeSpace[i]) and (
                        fit_spaces_limit_[i] + memory_reqquest_list_limit_ <= theOtherLimit):
            fit_blocks[i].append(requestName)
            fit_blocks_usefull[i].append(memoryRequest)
            fitSpaces[i] += memoryRequest

            fit_spaces_limit_[i] += memory_reqquest_list_limit_

            return 1,fitSpaces,fit_spaces_limit_,fit_blocks,fit_blocks_usefull
    return 0,fitSpaces,fit_spaces_limit_,fit_blocks,fit_blocks_usefull


def commonFit(freeSpace,theOtherLimit, limitRequests, fit_func,theOtherRequestList,requestNames):
    fit_spaces = [0]*(len(freeSpace))
    fit_spaces_limit = [0]*(len(freeSpace))
    fit_blocks = [[] for i in range(len(freeSpace))]
    fit_blocks_usefull = [[] for i in range(len(freeSpace))]
    num_fitted = 0
    delte = {}

    for index,memoryRequest in enumerate(limitRequests):
        requestName = requestNames[index]
        memory_reqquest_list_limit_ = theOtherRequestList[index]
        fitted,fit_spaces,fit_spaces_limit,fit_blocks,fit_blocks_usefull= fit_func(freeSpace, theOtherLimit,memoryRequest, fit_spaces, fit_spaces_limit,fit_blocks,fit_blocks_usefull,memory_reqquest_list_limit_,requestName)
        num_fitted += fitted
        if fitted ==0:
            freeSpace.append(freeSpace[0])
            return 0,0,0,0
    success = num_fitted / float(len(limitRequests))

    use_full = list(sum(i) for i in fit_blocks_usefull)
    use_full = dict(Counter(use_full))
    if use_full.get(freeSpace[0],0) == (len(fit_blocks_usefull) -1) and len(fit_blocks_usefull[-1]) < 2:
        delte = dict(Counter(fit_blocks_usefull[-1]))


    for inedx in range(len(fit_blocks_usefull)):
        if fit_blocks_usefull[-1] == []:
            fit_blocks_usefull.pop(-1)
    all_sum =0
    for i in fit_blocks_usefull:
        all_sum += sum(i)
    rate = all_sum / sum(freeSpace)
    return num_fitted, fit_blocks,delte,rate
