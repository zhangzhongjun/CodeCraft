# coding=utf-8
import math

def getParams():
    k = 1.0
    a = [1.0,2.0,3.0]
    res = []
    sum = 0.0
    for ai in a:
        res.append(math.exp(-(ai**2/(2*k**2))))
        sum = sum + math.exp(-(ai**2/(2*k**2)))
    return (res[0]/sum,res[1]/sum,res[2]/sum)
if __name__ == "__main__":
    print(getParams())