#coding=utf-8
from collections import Counter
import math
import time
from ZX import allocate

def getParams():
    k = 1.0
    a = [1.0,2.0,3.0]
    res = []
    sum = 0.0
    for ai in a:
        res.append(math.exp(-(ai**2/(2*k**2))))
        sum = sum + math.exp(-(ai**2/(2*k**2)))
    return (res[0]/sum,res[1]/sum,res[2]/sum)

def predict_vm(ecsDataPath, inputFilePath,resultFilePath):
    all_hat =[]
    all_hat_name = []
    all_hat_limit = []
    pre_dic={}
    FNL8 = []
    cons1 = 1024
    cons2 = 4

    data = open(inputFilePath).readlines()
    data2 = open(ecsDataPath).readlines()
    norms, flavor_name, CM, numberOfMat,test_time = read_inputfile(data2, data)

    if CM =="CPU":
        zero_one = 0
    elif CM =="MEM":
        zero_one = 1
    else:
        raise ("memory_alloction_name must be CPU OR MEM")

        
    for index, f_n in enumerate(flavor_name):
        flavor = flavor_name.values()[index]

        if CM =="CPU":
            flavor_cpu_or_mem = int(flavor[0])
            flavor_cpu_or_mem_limit = int(flavor[1]/cons1)
        else:
            flavor_cpu_or_mem = int(flavor[1]/cons1)
            flavor_cpu_or_mem_limit = int(flavor[0])
            

        labelMat = numberOfMat[index]
        
        yhat = M15(labelMat, test_time)
        pre = int(yhat)

        if f_n == "flavor1":
            pre = pre + 3
        if  f_n=="flavor12" or f_n=="flavor13" or f_n=="flavor14" or f_n=="flavor15":
            pre = pre - 1
            if pre < 0:
                pre = 0
        if f_n=="flavor11":
            pre = pre + 3 

        if pre !=0 :
            all_hat.extend([flavor_cpu_or_mem] * pre)
            all_hat_limit.extend([flavor_cpu_or_mem_limit] * pre)
            all_hat_name.extend([f_n] * pre)

        if int(f_n[6:]) < 8:
            FNL8.append(f_n)
        pre_dic[f_n] = pre

    result, delet, rate = allocate(norms[zero_one], norms[1 - zero_one], all_hat,all_hat_limit, all_hat_name,cons2)


    list_add_pre_less_8 = [0] * len(FNL8)
    best_list_add_pre_less_8 = list_add_pre_less_8[:]
    bestRate = 0
    best_result = []
    orig_all_hat = all_hat[:]
    orig_all_hat_limit = all_hat_limit[:]
    orig_all_hat_name = all_hat_name[:]
    orig_pre_dic = pre_dic.copy()
    for i in range(cons2**len(FNL8)):
        t =i
        all_hat = orig_all_hat[:]
        all_hat_limit = orig_all_hat_limit[:]
        all_hat_name = orig_all_hat_name[:]
        pre_dic = orig_pre_dic.copy()
        for j in range(len(FNL8)):
            list_add_pre_less_8[j] = t % cons2
            t = t/cons2
        for list_index,n in enumerate(list_add_pre_less_8):
            pre_dic[FNL8[list_index]] = pre_dic[FNL8[list_index]] + n
            flavor = flavor_name[FNL8[list_index]]

            flavor_cpu_or_mem = int(flavor[zero_one] if not zero_one else flavor[zero_one] / cons1)
            flavor_cpu_or_mem_limit = int(flavor[1 - zero_one] if zero_one else flavor[1-zero_one] / cons1)
            f_n =FNL8[list_index]
            if n !=0:
                all_hat.extend([flavor_cpu_or_mem] * n)
                all_hat_limit.extend([flavor_cpu_or_mem_limit] * n)
                all_hat_name.extend([f_n] * n)
        loopResult,delet,loopRate = allocate(norms[zero_one], norms[1 - zero_one], all_hat, all_hat_limit, all_hat_name,cons2)
        if loopRate> bestRate:
            bestRate = loopRate
            best_result = loopResult[:]
            best_pre = pre_dic.copy()
            best_all_hat = all_hat[:]
            best_list_add_pre_less_8 = list_add_pre_less_8[:]
    
    if  (bestRate - rate < 0.02) and sum(best_list_add_pre_less_8)<10:
        best_result = result[:]
        best_pre = orig_pre_dic.copy()
        best_all_hat = orig_all_hat[:]

    all_flavor = len(best_all_hat)
    need_xuniji_num = len(best_result)

    output_writer(all_flavor,best_pre,best_result,need_xuniji_num,resultFilePath)

def output_writer(all_flavor,pre_dic,result,need_xuniji_num,resultFilePath):
    file = open(resultFilePath,"w")
    result_list = []
    line_result = []
    for i in result:
        line_result.extend(i)
        result_list.append(dict(Counter(i)))

    line_result_dict = dict(Counter(line_result))

    pre_dic = sorted(pre_dic.items(), key=lambda x: x[0])
    file.write(str(all_flavor) + "\n")
    [file.write(key+" "+str(value)+"\n") for (key,value) in pre_dic]
    file.write("\n")
    file.write(str(need_xuniji_num)+"\n")

    for index,i in enumerate(result_list):
        dict_i = dict(i)
        file.write(str(index+1))
        [file.write(" "+key + " " + str(value)) for  key, value in dict_i.items()]
        if index+1<len(result_list):
            file.write("\n")
            
def cumsum(arr):
    sum = 0
    res = []
    for a in arr:
        sum = sum + a
        res.append(sum)
    return res
def M15(flavor_list,test_time):
    flavor_list = cumsum(flavor_list)
    mean_add = flavor_list[-1] /float(len(flavor_list))
    efficity_add = len(list(set(flavor_list))) /float(len(flavor_list))
    predict1 = math.ceil(mean_add * efficity_add *test_time)
    mean_add = flavor_list[-1] *1.5 / float(len(set(flavor_list)) -1)
    predict2 = math.ceil(mean_add  * test_time)
    if len(set(flavor_list[int(len(flavor_list) * 0.9):])) ==1:
        mean_add = (flavor_list[-1] - flavor_list[int(len(flavor_list) * 0.9)]) / float(len(set(flavor_list[int(len(flavor_list) * 0.9):])))
    else:
        mean_add = (flavor_list[-1] - flavor_list[int(len(flavor_list) * 0.9)]) / float(
            len(set(flavor_list[int(len(flavor_list) * 0.9):]))-1)


    predict3 = math.ceil(mean_add * test_time)
    if len(set(flavor_list[int(len(flavor_list) * 0.6):])) ==1:
        mean_add = ( flavor_list[-1] -  flavor_list[int(len(flavor_list) * 0.6)]) / float(len(set(flavor_list[int(len(flavor_list) * 0.6):])))
    else:
        mean_add = (flavor_list[-1] - flavor_list[int(len(flavor_list) * 0.6)]) / float(
            len(set(flavor_list[int(len(flavor_list) * 0.6):])) - 1)
    predict4 = math.ceil(mean_add * test_time)

    params = getParams()
    return (predict2 * params[0] +predict3 * params[1] + predict4* params[2])
    #return (predict2 * 0.7 +predict3 * 0.2 + predict4* 0.1)
            

def read_inputfile(data2,data ):
    threshold = 2
    norms = data[0].split()
    shuliang = int(data[2])
    flavor_name = {i.split(" ")[0]:[int(i.split(" ")[1].strip("\n")),int(i.split(" ")[2].strip("\n"))] for i in data[3:shuliang + 3]}

    cpu_mem = data[shuliang + 4].strip("\n").strip("\r")

    startTime = data[shuliang + 6].strip("\n").strip("\r").split(" ")[0]
    stopTime = data[shuliang + 7].strip("\n").strip("\r").split(" ")[0]

    numberOfMat = read_train_file(data2, flavor_name,startTime)
    test_time = getday(startTime,stopTime) 
    return norms,flavor_name,cpu_mem,numberOfMat,test_time


def read_train_file(data2,flavor_name,startTime):
    threshold = 2
    start = data2[0].split("\t")[2].strip("\n").strip("\r").split(" ")[0]
    start_weekday = date_change(start) % 7
    stop = getday(start,data2[-1].split("\t")[2].strip("\n").strip("\r"))
    if getday(data2[-1].split("\t")[2].strip("\n").strip("\r"),startTime)!=1:
        stop = stop + getday(data2[-1].split("\t")[2].strip("\n").strip("\r"),startTime)-1

    N = [[0] * (stop + 1) for x in xrange(len(flavor_name.keys()))]
    sumup = 0
    for j in data2:
        m = j.strip("\n").split("\t")
        try:
            mm = list(flavor_name.keys()).index(m[1])
            s = getday(start, m[2].strip("\r"))
            N[mm][getday(start,m[2].strip("\r"))] = N[mm][getday(start,m[2].strip("\r"))]+1
        except:
            continue

    for N_index,i in enumerate(N):
        i = flouth_data(i, threshold)
    return N
    
    
def date_change(date):
    timeArray = time.strptime(date, "%Y-%m-%d")
    timeStamp = int(time.mktime(timeArray))
    return timeStamp/86400

def getday(start,stop):
    start= start.split(" ")[0]
    stop =  stop.split(" ")[0]
    s = date_change(start)
    e = date_change(stop)
    return e-s
def flouth_data(L, threshold):
    if len(L) - L.count(0) !=0:
        mean_incres = float(sum(L)- L[0])/(len(L) - L.count(0))
        for i in range(len(L)-1):
            if L[i + 1] - L[i] > mean_incres * threshold:
                L[i + 1] =  0
    return L

